import React, { useState } from "react";

const vmcData = [
  {
    brand: "FANUC",
    model: "ROBODRILL α-D21SiB",
    x: 500,
    y: 400,
    z: 330,
    spindle: "10000-24000 RPM",
    toolCapacity: "14 or 21",
    tableSize: "650 x 400 mm",
    load: "250 kg",
    accuracy: "±0.006–0.020 mm",
    price: "₹45–60 lakh",
  },
  {
    brand: "Brother",
    model: "SPEEDIO S700X1",
    x: 700,
    y: 400,
    z: 300,
    spindle: "10000-27000 RPM",
    toolCapacity: "14 or 21",
    tableSize: "800 x 400 mm",
    load: "250 kg",
    accuracy: "±0.006–0.020 mm",
    price: "₹40–55 lakh",
  },
  {
    brand: "Haas",
    model: "DT-1",
    x: 508,
    y: 406,
    z: 394,
    spindle: "15000-20000 RPM",
    toolCapacity: "20",
    tableSize: "660 x 381 mm",
    load: "250 kg",
    accuracy: "±0.01 mm",
    price: "₹45–65 lakh",
  },
];

export default function VMCCompare() {
  const [selectedModels, setSelectedModels] = useState([]);

  const handleSelect = (modelName) => {
    const selected = vmcData.find((m) => m.model === modelName);
    setSelectedModels((prev) =>
      prev.find((m) => m.model === modelName)
        ? prev.filter((m) => m.model !== modelName)
        : [...prev.slice(-1), selected]
    );
  };

  return (
    <div className="p-4">
      <div className="flex gap-4 mb-4">
        {vmcData.map((vmc) => (
          <button
            key={vmc.model}
            onClick={() => handleSelect(vmc.model)}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            {vmc.model}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {selectedModels.map((vmc) => (
          <div key={vmc.model} className="border p-4 rounded shadow">
            <h2 className="text-lg font-bold mb-2">{vmc.brand} - {vmc.model}</h2>
            <ul className="text-sm">
              <li><strong>X/Y/Z Travel:</strong> {vmc.x}/{vmc.y}/{vmc.z} mm</li>
              <li><strong>Spindle Speed:</strong> {vmc.spindle}</li>
              <li><strong>Tool Capacity:</strong> {vmc.toolCapacity}</li>
              <li><strong>Table Size:</strong> {vmc.tableSize}</li>
              <li><strong>Max Load:</strong> {vmc.load}</li>
              <li><strong>Accuracy:</strong> {vmc.accuracy}</li>
              <li><strong>Price:</strong> {vmc.price}</li>
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
