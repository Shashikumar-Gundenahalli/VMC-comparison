import React from "react";
import ReactDOM from "react-dom/client";
import VMCCompare from "./VMCCompare";
import './style.css';

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <VMCCompare />
  </React.StrictMode>
);
